package com.example.practice8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
